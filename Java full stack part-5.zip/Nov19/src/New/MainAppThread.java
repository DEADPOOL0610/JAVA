package New;

class MyClass extends Thread{
	public void run() {
		for(int i=0; i<=5; i++) {
		System.out.println("run method "+Thread.currentThread()+""+i);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}
public class MainAppThread {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("JVM Thread "+Thread.currentThread());
		MyClass obj = new MyClass();
		obj.setName(" First ");
		MyClass obj1 = new MyClass();
		obj1.setName(" Second ");
		obj.start();
		obj.join();
		obj1.start();
	}

}
