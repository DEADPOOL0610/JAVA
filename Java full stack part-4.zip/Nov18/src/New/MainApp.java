package New;

import java.util.HashSet;


public class MainApp {


	public static void main(String[] args) {
		//Set->Interface->will not allow duplicate values
		//HashSet, does not maintain insertion order
		           //single null is allowed
		           //no duplicate values
		//LinkedHashSet
		//TreeSet
		
		HashSet<Integer> hobj = new HashSet<Integer>();
		hobj.add(67);
		hobj.add(67);
		hobj.add(67);
		hobj.add(87);
		hobj.add(90);
		hobj.add(null);
		
		System.out.println(hobj);

	}


}
