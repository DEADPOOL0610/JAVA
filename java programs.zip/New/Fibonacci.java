package New;
import java.util.Scanner;
public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a numer");
		int n=s.nextInt();
		int f1=0;
		int f2=1,f3;
		System.out.println(f1);
		System.out.println(f2);
		for(int i=3; i<=n; i++) {
			f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
			
		}
		

	}

}
