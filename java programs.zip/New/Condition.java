package New;
import java.util.Scanner;
public class Condition {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter a number");
		int n = s.nextInt();
		if(n>0) {
			System.out.println("Positive");
		}
		else if(n<0) {
			System.out.println("Negetive");
		}
		else {
			System.out.println("The entered number is 0");
		}
	}

}
