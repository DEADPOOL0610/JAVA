package New;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=1; i<=5; i++);{
			System.out.println(i);
		}
		System.out.println(i);

	}

}
