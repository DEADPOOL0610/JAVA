package New;

public class Evennum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=0; i<=100; i++) {
			if(i%2==0) {
				System.out.println(i);
			}
		}

	}

}
