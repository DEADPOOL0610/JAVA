package New;

import java.util.*;

public class Bignum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("enter value of a");
		int a=s.nextInt();
		System.out.println("enter value of b");
		int b=s.nextInt();
		System.out.println("enter value of c");
		int c=s.nextInt();
		System.out.println("enter value of d");
		int d=s.nextInt();
		int big = (a>b && a>c && a>d)?a:(b>a && b>c && b>d)?b:(c>a && c>b && c>d)?c:d;
		System.out.println("The largest Number  among "+a+" , " +b+ " , " +c+ " and "+d+ " is "+big);

	}

}
