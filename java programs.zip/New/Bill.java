package New;

import java.util.Scanner;

public class Bill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your Name ");
		String name = s.next();
		System.out.println("enter no.of units consumed ");
		int n = s.nextInt();
		if(n>0 && n<=100) {
			n= n*2;
		}
		else if(n>100 && n<=200) {
			n= 100*2+(n-100)*3;
		}
		else if(n>300) {
			n= 100*2+200*3+(n-300)*5;
		}
		else {
			System.out.println("Invalid Input");
		}
		System.out.println(name+" the total amount is: "+n);

	}

}
