package New;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("enter a number");
		int num=s.nextInt();
		long fact=1;
		for(int i=num; i>=1; i--) {
			fact = fact * i;
		}
		System.out.println("The factorial of "+num+" is: "+fact);

	}

}
