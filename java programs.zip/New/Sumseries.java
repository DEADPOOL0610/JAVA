package New;

public class Sumseries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=1; i<=100; i++) {
			sum += i;
		}
		System.out.println("The Sum of 1-100 is: "+sum);

	}

}
