package New;
import java.util.Scanner;
public class Grade {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter marks");
		int marks=sc.nextInt();
		  if (marks > 100 || marks < 0) {
	          System.out.println("Invalid marks");
		  }
	          else if(marks>=90 && marks<=100) {
			System.out.println("The Grade is A");
		}else if(marks>=80 && marks<=89) {
			System.out.println("The Grade is B");
		}else if(marks>=50 && marks<=79) {
			System.out.println("The Grade is C");
		}else if(marks>=35 && marks<=49) {
			System.out.println("The Grade is D");
		}else if(marks>=0 && marks<=34) {
			System.out.println("The Grade is E");
	}


	}
	}
