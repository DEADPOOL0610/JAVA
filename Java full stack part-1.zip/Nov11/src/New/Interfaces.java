package New;
class Playable{
	void play(){
		System.out.println("Play an instrument");
	}
}

class Guitar implements Playable{
	@Override
	public void play(){
		System.out.println("Play guitar");
	}
}
class Piano implements Playable{
	@Override
	public void play(){
		System.out.println("Play Piano");
	}
}
public class Interfaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Guitar g = new Guitar();
		Piano p = new Piano();
		g.play();
		p.play();
	}

}
