package New;
import java.util.Scanner;

class Student{
	int id;
	String name;
	float fee;
	
	public Student() {
		id=14;
		name="pavan";
		fee=2000;
	}
	
	void inputdata() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter id");
		id= s.nextInt();
		System.out.println("Enter Name");
		name= s.next();
		System.out.println("enter fee");
		fee=s.nextFloat();
	}
	void display() {
		System.out.println("ID= "+id);
		System.out.println("Name= "+name);
		System.out.println("Fee= "+fee);
	}
}

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stobj = new Student();
		   stobj.inputdata();
		   stobj.display();

	}

}
