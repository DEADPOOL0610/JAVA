package New;
import java.util.Scanner;
public class Employee{
	int eid;
	String ename;
	float esalary;
	String edeptname;
	
	public Employee() {
		eid=0;
		ename=null;
		esalary=0;
		edeptname=null;
	}
	
	void inputdata() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Employee id");
		eid= s.nextInt();
		System.out.println("Enter Employee Name ");
		s.nextLine();
		ename= s.nextLine();
		System.out.println("Enter Salary ");
		esalary=s.nextFloat();
		System.out.println("Enter Department name ");
		s.nextLine();
		edeptname=s.nextLine();
	}
	void display() {
		System.out.println("ID= "+eid);
		System.out.println("Name= "+ename);
		System.out.println("Fee= "+esalary);
		System.out.println("Department= "+edeptname);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e =new  Employee();
		e.inputdata();
		e.display();
	}

}
