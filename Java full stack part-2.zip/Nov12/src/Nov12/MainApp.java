package Nov12;

interface Intf1{ //using interface we can achieve 100%
int i=10; //public static final
void m1(); //by default methods are public abstract
void m2();
}


interface Intf2{
void m3();
}
class MyClass implements Intf1,Intf2{


@Override
public void m1() {
System.out.println("m1 method of interface");

}


@Override
public void m2() {

System.out.println("m2 method of interface");
}


@Override
public void m3() {
System.out.println("m3 method of interface");

}

}


public class MainApp {


public static void main(String[] args) {
MyClass obj = new MyClass();
obj.m1();
obj.m2();
obj.m3();
}


}
