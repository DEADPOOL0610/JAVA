package Nov12;

import java.util.Scanner;

class Parent{
	private int id;
	public String name;
	protected float salary;
	
	public void inputdata() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter id ");
		id = s.nextInt();
		System.out.println("Enter Name ");
		name = s.next();
		System.out.println("Enter Salary ");
		salary = s.nextFloat();
	}
	void display() {
		System.out.println("ID "+id);
		System.out.println("Name "+name);
		System.out.println("Salary "+salary);
	}
}
class Child extends Parent{
	void display() {
		//System.out.println("ID "+id);
		System.out.println("Name "+name);
		System.out.println("Salary "+salary);
	}
}
public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child obj = new Child();
		obj.inputdata();
		obj.display();
	}

}
